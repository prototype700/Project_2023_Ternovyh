<!DOCTYPE html>
<html lang="ru">

<head>
    <title>Kingpin Lanes & Lounge</title>
    <!-- Подключаем Bootstrap CSS -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="styles.css" />
    <meta http-equiv="Content-type" content="text/html;charset=UFT-8" />
</head>

<body>
    <header>
        <div class="container-fluid head_osnova">
            <div class="row align-items-center">
                <div class="col-md-3 col-sm-6 logo">
                    <a href="index.php"><img src="pictures/Лого.png" width="61px" height="68px" alt="лого"></a>
                    <h5 class="txt3_head">Kingpin Lanes & Lounge</h5>
                </div>
                <div class="col-md-6 col-sm-6 navhead">
                    <nav>
                        <a href="index.php">Боулинг</a>
                        <a href="index.php">Акции</a>
                        <a href="menu.php">Меню</a>
                    </nav>
                </div>
                <div class="col-md-3 col-sm-12 d-flex justify-content-end logomess">
                    <a href="https://vk.com/prototype70"><img src="pictures/icons8-whatsapp-50 1.png" alt="whatsapp"></a>
                    <a href="https://vk.com/prototype70"><img src="pictures/icons8-вконтакте-64 1.png" alt="vk"></a>
                    <?php if (isset($_SESSION['username'])): ?>
                <a href="logout.php"><img src="pictures/logout.png" alt="logout" style="width: 40px; height: 40px;"></a>
            <?php else: ?>
                <a href="login.php"><img src="pictures/lk.png" alt="tg" style="width: 40px; height: 40px;"></a>
            <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-12 d-flex justify-content-end number">
                    <p>7(923)412-90-45</p>
                    
                </div>
            </div>
        </div>
        <div class="poloska"></div>
    </header>

    <div class="container">
        <h2 class="text-center my-5"><b>Авторизация</b></h2>

        <form action="login_action.php" method="post">
            <div class="form-group">
              <label for="username">Логин:</label>
              <input type="text" class="form-control" id="username" name="username">
            </div>
            <div class="form-group">
              <label for="password">Пароль:</label>
              <input type="password" class="form-control" id="password" name="password">
            </div>
            <button type="submit" class="btn btn-success">Войти</button>
            <p class="register-link">Еще не зарегистрировались? <a class="register-link" href="register.php">Зарегистрироваться</a></p>
          </form>
    </div>

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-12">
                    <div class="foot_txt">
                        <a name="Контакты" href="#"><p>© Kingpin Lanes & Lounge</p></a> 
                        <p> г. Барнаул, пр. Комсомольский 100</p>
                        <p>Режим работы: Воскресенье – Четверг с 10:00 до 2:00</p>
                        <p>Пятница – Суббота с 10:00 до 3:00</p>
                        <p>Телефон для бронирования: +7 923 415 90 45</p>
                        <p>Email: krutoi_sait@pochki.net</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Подключаем Bootstrap JS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
</body>

</html>
