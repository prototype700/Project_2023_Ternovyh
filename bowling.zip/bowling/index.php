<!DOCTYPE html>
<html lang="ru">

<head>
    <title>Kingpin Lanes & Lounge</title>
    <!-- Подключаем Bootstrap CSS -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="styles.css" />
    <meta http-equiv="Content-type" content="text/html;charset=UFT-8" />
</head>

<body>
    <header>
        <div class="container-fluid head_osnova">
            <div class="row align-items-center">
                <div class="col-md-3 col-sm-6 logo">
                    <a href="index.php"><img src="pictures/Лого.png" width="61px" height="68px" alt="лого"></a>
                    <h5 class="txt3_head">Kingpin Lanes & Lounge</h5>
                </div>
                <div class="col-md-6 col-sm-6 navhead">
                    <nav>
                        <a href="#Боулинг">Боулинг</a>
                        <a href="#Акции">Акции</a>
                        <a href="menu.php">Меню</a>
                    </nav>
                </div>
                <div class="col-md-3 col-sm-12 d-flex justify-content-end logomess">
                    <a href="https://vk.com/prototype70"><img src="pictures/icons8-whatsapp-50 1.png" alt="whatsapp"></a>
                    <a href="https://vk.com/prototype70"><img src="pictures/icons8-вконтакте-64 1.png" alt="vk"></a>
                    <?php if (isset($_SESSION['username'])): ?>
                <a href="logout.php"><img src="pictures/logout.png" alt="logout" style="width: 40px; height: 40px;"></a>
            <?php else: ?>
                <a href="login.php"><img src="pictures/lk.png" alt="tg" style="width: 40px; height: 40px;"></a>
            <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-12 d-flex justify-content-end number">
                    <p>7(923)412-90-45</p>
                </div>
            </div>
        </div>
        <div class="poloska"></div>
    </header>

    <div class="container">
           <!-- Подключаем Bootstrap CSS
        <img src="pictures/кегельбан.jpg" class="kegel img-fluid" alt="kegelban">  -->
        <p class="hello text-center"><b>Добро пожаловать в Kingpin Lanes & Lounge!</b><br> Здесь вы найдете отличные условия для игры в боулинг, а также множество развлечений и услуг для всей семьи.<br> Наши современные кегельбаны, комфортабельные зоны отдыха и разнообразный барный меню гарантируют вам незабываемые впечатления и отличный отдых.<br> Присоединяйтесь к нам и окунитесь в мир веселья и спортивного соревнования!</p>

        <h2 class="text-center my-5"><a name="Боулинг"><b>ЦЕНА ПОСЕЩЕНИЯ БОУЛИНГА</b></a></h2>
        <a id="upbutton" href="#" onclick="smoothJumpUp(); return false;"></a>

        <div class="row">
            <div class="col-12 col-md-6 tarif">
                <p class="text-center">ТАРИФ “ОБЩИЙ” <br>Стоимость 1 дорожки</p>
                <ul><b>Включает в себя: </b>
                    <li>Доступ к кегельбанам</li>
                    <li>Оборудование для игры (боулинг-перчатки и кегли)</li>
                    <li>Возможность аренды боулинг-кроссовок</li>
                    <li>Доступ к барному меню и напиткам</li>
                </ul>
                <hr>
                <p class="text-center">Понедельник - Четверг</p>
                <hr>
                <p class="text-center">С 10:00 до 17:00 - 800 руб/час</p>
                <p class="text-center">С 17:00 до 02:00 - 1500 руб/час</p>
                <hr>
                <p class="text-center">Пятница</p>
                <hr>
                <p class="text-center">С 10:00 до 17:00 - 1200 руб/час</p>
                <p class="text-center">С 17:00 до 03:00 - 1800 руб/час</p>
                <hr>
                <p class="text-center">Суббота</p>
                <hr>
                <p class="text-center">С 10:00 до 03:00 - 1600 руб/час</p>
                <hr>
                <p class="text-center">Воскресенье/Праздничные дни</p>
                <hr>
                <p class="text-center">С 10:00 до 02/03:00 - 1700 руб/час</p>
                <button class="btn btn-primary mt-3" type="button" onclick="location.href='login.php'">Забронировать</button>

            </div>
            <div class="col-12 col-md-6 tarif">
                <p class="text-center">ТАРИФ “VIP” <br>Стоимость 1 дорожки</p>
                <ul><b>Включает в себя: </b>
                    <li>Личный менеджер для организации игры</li>
                    <li>Доступ к отдельным кегельбанам VIP-класса</li>
                    <li>Оборудование для игры премиум-класса (боулинг-перчатки и кегли)</li>
                    <li>Бесплатная аренда боулинг-кроссовок</li>
                    <li>Доступ к барному меню премиум-класса</li>
                    <li>Возможность организации корпоративных мероприятий и частных вечеринок</li>
                </ul>
                <hr>
                <p class="text-center">Понедельник - Четверг</p>
                <hr>
                <p class="text-center">С 10:00 до 17:00 - 1400 руб/час</p>
                <p class="text-center">С 17:00 до 02:00 - 2700 руб/час</p>
                <hr>
                <p class="text-center">Пятница</p>
                <hr>
                <p class="text-center">С 10:00 до 17:00 - 2100 руб/час</p>
                <p class="text-center">С 17:00 до 03:00 - 3500 руб/час</p>
                <hr>
                <p class="text-center">Суббота</p>
                <hr>
                <p class="text-center">С 10:00 до 03:00 - 2600 руб/час</p>
                <hr>
                <p class="text-center">Воскресенье/Праздничные дни</p>
                <hr>
                <p class="text-center">С 10:00 до 02/03:00 - 2800 руб/час</p>
                <button class="btn btn-primary mt-3" type="button" onclick="location.href='login.php'">Забронировать</button>

            </div>
        </div>
        
    </div>

    <h1 class="text-center my-5"><a name="Акции"><b>НАШИ АКЦИИ</b></a></h1>

    <div class="container">
        <div class="row">
            <div class="col-12 col-md-6">
                <div class="birthday">
                    <img class="img-fluid rounded-start" src="pictures/cake is a lie.jpg" alt="тортик">
                    <p class="text-center mt-4"><b>День рождения</b></p>
                    <p class="ms-4">Скидка 30% в течение 7 дней (3 дня до и после ДР) при предъявлении документа*<br><br>С собой можно принести тематические вещи и торт при<br> наличии предварительного заказа от 1500 руб<br>*Скидки не суммируются</p>
                </div>
            </div>
            <div class="col-12 col-md-6 mt-4 mt-md-0">
                <div class="birthday">
                    <img class="img-fluid rounded-start" src="pictures/парты.jpg" alt="тортик">
                    <p class="text-center mt-3"><b>Учащимся</b></p>
                    <p class="ms-4">Скидка 25% для школьников и студентов при предъявлении документа*<br><br>Действует с понедельника по четверг с 9 до 20 часов<br>*Скидки не суммируются</p>
                </div>
            </div>
        </div>
    </div>

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-12">
                    <div class="foot_txt">
                        <a name="Контакты" href="#"><p>© Kingpin Lanes & Lounge</p></a> 
                        <p> г. Барнаул, пр. Комсомольский 100</p>
                        <p>Режим работы: Воскресенье – Четверг с 10:00 до 2:00</p>
                        <p>Пятница – Суббота с 10:00 до 3:00</p>
                        <p>Телефон для бронирования: +7 923 415 90 45</p>
                        <p>Email: krutoi_sait@pochki.net</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Подключаем Bootstrap JS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
</body>

</html>
