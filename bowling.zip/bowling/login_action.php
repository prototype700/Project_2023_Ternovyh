<?php
session_start(); // Начинаем сессию в начале скрипта

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bowling";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("не удалось подключиться: " . $conn->connect_error);
}

$username = $_POST['username'];
$password = $_POST['password'];

// Используем подготовленные выражения для предотвращения SQL-инъекций
$stmt = $conn->prepare("SELECT * FROM users WHERE username = ? AND password = ?");
$stmt->bind_param("ss", $username, $password);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $_SESSION['username'] = $username;
    header('Location: form.php');
} else {
    // Можно добавить сообщение об ошибке, если логин или пароль неверны
    $_SESSION['error'] = 'Неверный логин или пароль';
    header('Location: login.php');
}

$stmt->close();
$conn->close();
?>
