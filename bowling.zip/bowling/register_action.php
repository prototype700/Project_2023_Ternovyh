<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bowling";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
  die("не удалось подключиться: " . $conn->connect_error);
}

$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password'];
$confirm_password = $_POST['confirm-password'];

if ($password == $confirm_password) {
    $sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$password')";

    if ($conn->query($sql) === TRUE) {
      header('Location: form.php');
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "пароли не совпадают";
}

$conn->close();
?>